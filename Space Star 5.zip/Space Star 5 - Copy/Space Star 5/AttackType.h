#pragma once
#ifndef _ATTACK_TYPE_H
#define _ATTACK_TYPE_H

enum AttackType
{
	ATTACK1,ATTACK2,ATTACK3,ATTACK4,ATTACK5,
	AVOID1,AVOID2
};

#endif